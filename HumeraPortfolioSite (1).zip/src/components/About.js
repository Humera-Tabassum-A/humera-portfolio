import React from "react";

const About = () => {
  return (
    <section id="about" className="py-20 px-6 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-4 text-pink-600">About Me</h2>
      <p className="text-lg">
        I'm a detail-oriented and enthusiastic Computer Science Engineering student at Dayananda Sagar University with a strong passion for solving real-world problems using data analysis, software development, and image processing. I enjoy working on projects that combine machine learning, computer vision, and backend technologies.
      </p>
    </section>
  );
};

export default About;
