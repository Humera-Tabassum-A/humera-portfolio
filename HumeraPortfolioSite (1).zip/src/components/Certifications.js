import React from "react";

const certifications = [
  "Image Processing Onramp – MathWorks",
  "MATLAB Onramp – MathWorks",
  "SQL (Basic, Intermediate, Advanced) – HackerRank"
];

const Certifications = () => {
  return (
    <section id="certifications" className="py-20 px-6 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-6 text-pink-600">Certifications</h2>
      <ul className="list-disc pl-6 space-y-2">
        {certifications.map((cert, index) => (
          <li key={index} className="text-gray-800">{cert}</li>
        ))}
      </ul>
    </section>
  );
};

export default Certifications;
