import React from "react";

const Contact = () => {
  return (
    <section id="contact" className="py-20 px-6 max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-6 text-pink-600">Contact</h2>
      <p className="mb-4">Feel free to reach out to me via the links below:</p>
      <ul className="space-y-2">
        <li><strong>Phone:</strong> <a className="text-pink-700 hover:underline" href="tel:+919916235715">+91-9916235715</a></li>
        <li><strong>Email:</strong> <a className="text-pink-700 hover:underline" href="mailto:humeratabbu30@gmail.com">humeratabbu30@gmail.com</a></li>
        <li><strong>GitHub:</strong> <a className="text-pink-700 hover:underline" href="https://github.com/Humera-Tabassum-A" target="_blank" rel="noopener noreferrer">Humera-Tabassum-A</a></li>
        <li><strong>LinkedIn:</strong> <a className="text-pink-700 hover:underline" href="https://www.linkedin.com/in/humera-tabassum-a-355648259" target="_blank" rel="noopener noreferrer">linkedin.com/in/humera-tabassum-a</a></li>
      </ul>
    </section>
  );
};

export default Contact;
