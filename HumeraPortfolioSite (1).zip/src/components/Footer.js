import React from "react";

const Footer = () => {
  return (
    <footer className="text-center py-6 bg-pink-100 text-sm">
      <p>© {new Date().getFullYear()} Humera Tabassum. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
