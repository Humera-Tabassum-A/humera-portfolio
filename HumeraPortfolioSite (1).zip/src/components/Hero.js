import React from "react";
import { motion } from "framer-motion";

const Hero = () => {
  return (
    <section className="h-screen flex flex-col justify-center items-center text-center px-4 bg-gradient-to-r from-pink-500 to-pink-700" id="hero">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}>
        <h1 className="text-5xl font-bold mb-4">Hi, I'm Humera Tabassum 👩‍💻</h1>
        <p className="text-xl mb-2">Computer Science Student | Developer | ML & CV Enthusiast</p>
        <p className="text-sm">Bengaluru, Karnataka, India</p>
      </motion.div>
    </section>
  );
};

export default Hero;
