import React from "react";

const projects = [
  {
    title: "MyETPWallet",
    description: "A lightweight and secure cryptocurrency wallet using SPV, Firebase, and REST APIs.",
  },
  {
    title: "Real Estate Price Prediction",
    description: "ML-based web app for predicting Bangalore property prices using Scikit-learn and Flask.",
  },
  {
    title: "Pest Detection and Classification",
    description: "CNN-based image classification system to identify pests with high accuracy.",
  },
  {
    title: "Medical Store Management System",
    description: "A SQL-based system to manage medical store operations efficiently.",
  },
  {
    title: "Image Stitching using FLANN and RANSAC",
    description: "Panoramic image generation using feature matching and computer vision algorithms.",
  }
];

const Projects = () => {
  return (
    <section id="projects" className="py-20 px-6 max-w-6xl mx-auto">
      <h2 className="text-3xl font-bold mb-10 text-pink-600">Projects</h2>
      <div className="grid md:grid-cols-2 gap-6">
        {projects.map((project, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6 hover:shadow-xl transition">
            <h3 className="text-xl font-semibold text-pink-700 mb-2">{project.title}</h3>
            <p className="text-gray-800">{project.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Projects;
