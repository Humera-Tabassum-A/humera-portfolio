import React from "react";

const Skills = () => {
  return (
    <section id="skills" className="py-20 px-6 max-w-6xl mx-auto">
      <h2 className="text-3xl font-bold mb-10 text-pink-600">Skills</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 text-center">
        {[
          "Java", "Python", "C", "SQL",
          "HTML", "CSS", "TensorFlow", "Keras",
          "OpenCV", "NumPy", "Pandas", "Matplotlib",
          "Scikit-learn", "DBMS", "Excel", "Power BI"
        ].map((skill, index) => (
          <div key={index} className="bg-white p-4 rounded shadow hover:bg-pink-100">
            {skill}
          </div>
        ))}
      </div>
    </section>
  );
};

export default Skills;
