module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: '#ec4899',
        secondary: '#f472b6',
      }
    },
  },
  plugins: [],
};
